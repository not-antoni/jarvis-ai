const { PermissionFlagsBits } = require('discord.js');
const database = require('../services/database');
const { isOwner: isOwnerCheck } = require('./owner-check');

const BOT_OWNER_ID = (process.env.BOT_OWNER_ID || process.env.ADMIN_USER_ID || '').trim();

/**
 * Check if a user matches "True Moderator" criteria
 * (Ban, Kick, Maintain Members permissions)
 */
function hasTrueModPerms(member) {
    if (!member) {return false;}
    return member.permissions.has(PermissionFlagsBits.BanMembers) &&
        member.permissions.has(PermissionFlagsBits.KickMembers) &&
        member.permissions.has(PermissionFlagsBits.ModerateMembers);
}

/**
 * Check if a user is a DJ Administrator (can configure DJ settings)
 * Criteria: Bot Owner OR Guild Owner OR Administrator OR True Mod
 */
function isDjAdmin(member, guildConfig) {
    if (!member) {return false;}

    // 1. Bot Owner override (uses centralized owner check)
    if (isOwnerCheck(member.id)) {return true;}

    // 2. Guild Owner override
    if (member.guild?.ownerId === member.id) {return true;}

    // 3. Configured Owner Match
    if (guildConfig?.ownerId === member.id) {return true;}

    // 4. Administrator Permission
    if (member.permissions.has(PermissionFlagsBits.Administrator)) {return true;}

    // 5. "True Mod" check
    if (hasTrueModPerms(member)) {return true;}

    return false;
}

/**
 * Check if a user is authorized to use DJ commands
 * Criteria: isDjAdmin OR Has DJ Role OR Is Whitelisted DJ User
 */
function isDj(member, guildConfig) {
    if (!member) {return false;}
    if (!guildConfig) {return false;} // Secure default: deny if config unavailable

    // Admins are always DJs
    if (isDjAdmin(member, guildConfig)) {return true;}

    // Check specific DJ Users list
    if (guildConfig.djUserIds && guildConfig.djUserIds.includes(member.id)) {return true;}

    // Check DJ Roles
    if (guildConfig.djRoleIds && guildConfig.djRoleIds.length > 0) {
        const hasDjRole = member.roles.cache.some(role => guildConfig.djRoleIds.includes(role.id));
        if (hasDjRole) {return true;}
    }

    return false;
}

/**
 * Check if a user is blocked from using music commands
 */
function isBlocked(userId, guildConfig) {
    if (!guildConfig) {return false;}
    return guildConfig.blockedUserIds && guildConfig.blockedUserIds.includes(userId);
}

async function sendMusicPermissionReply(target, content) {
    if (!target) {return;}

    // Discord interactions support ephemeral denial messages.
    if (!target.author && typeof target.reply === 'function') {
        const payload = { content, flags: 64 };
        try {
            if (target.deferred || target.replied) {
                if (typeof target.followUp === 'function') {
                    await target.followUp(payload);
                }
            } else {
                await target.reply(payload);
            }
        } catch {
            if (typeof target.followUp === 'function') {
                await target.followUp(payload).catch(() => {});
            }
        }
        return;
    }

    if (typeof target.reply === 'function') {
        await target.reply(content).catch(() => {});
        return;
    }

    if (target.channel?.send) {
        await target.channel.send({ content }).catch(() => {});
    }
}

/**
 * Main permission check for music commands
 * Usage: if (!await canControlMusic(interaction)) return;
 */
async function canControlMusic(interactionOrMessage, guildConfig = null) {
    const { member } = interactionOrMessage;
    const guildId = interactionOrMessage?.guildId || interactionOrMessage?.guild?.id;
    const userId = member?.id || interactionOrMessage?.author?.id;
    if (!member || !userId) {return false;}

    // Fetch config if not provided
    if (!guildConfig && guildId) {
        guildConfig = await database.getGuildConfig(guildId);
    }
    guildConfig = guildConfig || {};

    // 1. Check Blocklist (Except Bot Owner)
    if (!isOwnerCheck(userId) && isBlocked(userId, guildConfig)) {
        await sendMusicPermissionReply(interactionOrMessage, '🚫 You are blocked from using music commands.');
        return false;
    }

    // 2. Check if DJ Mode is enabled
    // Note: We need to determine where "DJ Mode Enabled" is stored.
    // For now, let's assume if DJ Roles/Users are set, we implicitly enforce it?
    // Or we should add an explicit toggle.
    // Let's add a feature flag check.
    const djModeEnabled = guildConfig.features?.dj_mode;

    if (djModeEnabled) {
        if (!isDj(member, guildConfig)) {
            await sendMusicPermissionReply(
                interactionOrMessage,
                '🔒 **DJ Mode is Active**\nYou need the DJ role or Admin permissions to control music.'
            );
            return false;
        }
    }

    return true;
}

module.exports = {
    isDjAdmin,
    isDj,
    isBlocked,
    canControlMusic
};
