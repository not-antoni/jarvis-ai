/**
 * Upload Queue Service
 * Processes file uploads one at a time to prevent bot overload
 * When many users upload simultaneously, they get queued and processed sequentially
 */
const { musicManager } = require('../core/musicManager');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const { assertPublicHttpUrl } = require('../utils/net-guard');

// Try to get ffprobe path from npm package, fall back to system
let ffprobePath = 'ffprobe';
try {
    ffprobePath = require('ffprobe-static').path;
} catch (e) {
    console.log('[UploadQueue] ffprobe-static not available, using system ffprobe');
}

/**
 * Get audio duration using ffprobe
 * @param {string} url - URL to probe
 * @returns {number} Duration in seconds, or 0 if failed
 */
async function getAudioDuration(url) {
    try {
        // Use network-friendly flags for remote URLs:
        // -reconnect 1: Reconnect on connection loss
        // -reconnect_streamed 1: Reconnect for streamed content
        // -reconnect_delay_max 5: Max 5 second reconnect delay
        // -timeout 10000000: 10 second timeout in microseconds
        const isRemote = /^https?:\/\//i.test(url);
        if (!isRemote) {
            console.warn('[UploadQueue] Rejecting non-HTTP URL for ffprobe.');
            return 0;
        }

        // Validate URL to avoid SSRF or local access.
        let safeUrl = null;
        try {
            safeUrl = await assertPublicHttpUrl(url);
        } catch (error) {
            console.warn('[UploadQueue] Rejecting unsafe URL for ffprobe:', error.message);
            return 0;
        }

        const args = [];
        if (isRemote) {
            args.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5');
        }
        args.push('-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', safeUrl);

        const { stdout } = await execFileAsync(
            ffprobePath,
            args,
            { timeout: 30000, encoding: 'utf8' }
        );
        const duration = parseFloat(stdout.trim());
        if (isNaN(duration) || duration <= 0) {
            console.warn('[UploadQueue] ffprobe returned invalid duration:', result.trim());
            return 0;
        }
        return Math.floor(duration);
    } catch (e) {
        console.warn('[UploadQueue] ffprobe failed:', e.message?.slice(0, 200));
        return 0;
    }
}

/**
 * Format seconds to MM:SS or HH:MM:SS
 */
function formatDuration(seconds) {
    if (!seconds || seconds <= 0) {return '0:00';}
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
        return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

class UploadQueue {
    constructor() {
        this.queue = []; // { guildId, voiceChannel, fileUrl, filename, member, textChannel, interaction, addedAt }
        this.processing = false;
        this.guildQueues = new Map(); // guildId -> [...items] for per-guild tracking
    }

    /**
     * Add an upload to the queue
     * @returns {number} Position in queue (1 = next up)
     */
    add(guildId, voiceChannel, fileUrl, filename, member, textChannel, interaction) {
        const item = {
            guildId,
            voiceChannel,
            fileUrl,
            filename,
            member,
            textChannel,
            interaction,
            addedAt: Date.now()
        };

        this.queue.push(item);

        // Track per-guild for position info
        if (!this.guildQueues.has(guildId)) {
            this.guildQueues.set(guildId, []);
        }
        this.guildQueues.get(guildId).push(item);

        const position = this.queue.length;
        console.log(`[UploadQueue] Added: ${filename} (Position: ${position}, Guild: ${guildId})`);

        // Start processing if not already
        if (!this.processing) {
            this.processNext();
        }

        return position;
    }

    /**
     * Get queue position for a guild
     */
    getGuildQueueLength(guildId) {
        return this.guildQueues.get(guildId)?.length || 0;
    }

    /**
     * Process the next item in the queue
     */
    async processNext() {
        if (this.queue.length === 0) {
            this.processing = false;
            return;
        }

        this.processing = true;
        const item = this.queue.shift();

        // Remove from guild queue tracking
        const guildQueue = this.guildQueues.get(item.guildId);
        if (guildQueue) {
            const idx = guildQueue.indexOf(item);
            if (idx > -1) {guildQueue.splice(idx, 1);}
            if (guildQueue.length === 0) {this.guildQueues.delete(item.guildId);}
        }

        console.log(`[UploadQueue] Processing: ${item.filename} (Remaining: ${this.queue.length})`);

        try {
            const manager = musicManager.get();

            // Probe file for duration
            console.log(`[UploadQueue] Probing duration for: ${item.filename}`);
            const durationSeconds = await getAudioDuration(item.fileUrl);
            const formattedDuration = formatDuration(durationSeconds);
            console.log(`[UploadQueue] Duration: ${formattedDuration} (${durationSeconds}s)`);

            // Pre-buffer: the ffprobe call above already downloads some data
            // Add small delay to let network stabilize before playback
            await new Promise(resolve => setTimeout(resolve, 500));

            const response = await manager.enqueue(
                item.guildId,
                item.voiceChannel,
                {
                    source: 'direct_link',
                    title: item.filename,
                    url: item.fileUrl,
                    duration: formattedDuration,
                    durationSeconds,
                    isUpload: true,
                    uploadPreviewUrl: item.fileUrl,
                    filename: item.filename
                },
                item.interaction
            );

            if (response && item.textChannel) {
                try {
                    await item.textChannel.send(response);
                } catch (_sendError) {
                    const fallback = typeof response === 'string' ? response : response?.content;
                    if (fallback) {
                        await item.textChannel.send(fallback).catch(() => { });
                    }
                }
            }

            console.log(`[UploadQueue] Success: ${item.filename}`);

        } catch (e) {
            console.error(`[UploadQueue] Failed: ${item.filename}`, e.message);

            // Notify user of failure
            try {
                await item.textChannel.send(`❌ Failed to process upload **${item.filename}**: ${e.message?.slice(0, 100) || 'Unknown error'}`);
            } catch (notifyErr) {
                // Ignore notification errors
            }
        }

        // Small delay between processing to be gentle on resources
        setTimeout(() => this.processNext(), 500);
    }

    /**
     * Get overall queue stats
     */
    getStats() {
        return {
            queueLength: this.queue.length,
            isProcessing: this.processing,
            guildsWithUploads: this.guildQueues.size
        };
    }
}

// Singleton instance
const uploadQueue = new UploadQueue();

module.exports = uploadQueue;
